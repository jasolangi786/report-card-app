package com.example.android.reportcard;

public class ReportCard {
    private String mSindhiGrade = "";
    private String mUrduGrade = "";
    private String mMusicGrade = "";
    private String mEnglishGrade = "";
    private String mHistoryGrade = "";
    private String mScienceGrade = "";
    private String mMathsGrade = "";
    private String mArtGrade = "";

    public ReportCard() {
        mSindhiGrade = "A";
        mUrduGrade = "B";
        mMusicGrade = "F";
        mEnglishGrade = "A";
        mHistoryGrade = "C";
        mScienceGrade = "D";
        mMathsGrade = "A";
        mArtGrade = "F";
    }

    public ReportCard(String sindhiGrade, String urduGrade, String musicGrade, String englishGrade, String historyGrade, String scienceGrade, String mathsGrade, String artGrade) {
        mSindhiGrade = sindhiGrade;
        mUrduGrade = urduGrade;
        mMathsGrade = musicGrade;
        mEnglishGrade = englishGrade;
        mHistoryGrade = historyGrade;
        mScienceGrade = scienceGrade;
        mMathsGrade = mathsGrade;
        mArtGrade = artGrade;
    }

    public String getSindhiGrade() {
        return mSindhiGrade;
    }

    public void setSindhiGrade(String sindhiGrade) {
        mSindhiGrade = sindhiGrade;

    }

    public String getUrduGrade() {
        return mUrduGrade;
    }

    public void setUrduGrade(String urduGrade) {
        mUrduGrade = urduGrade;
    }

    public String getMusicGrade() {
        return mMusicGrade;
    }

    public void setMusicGrade(String musicGrade) {
        mMusicGrade = musicGrade;
    }

    public String getEnglishGrade() {
        return mEnglishGrade;
    }

    public void setEnglishGrade(String englishGrade) {
        mEnglishGrade = englishGrade;
    }

    public String getHistoryGrade() {
        return mEnglishGrade;
    }

    public void setHistoryGrade(String historyGrade) {
        mHistoryGrade = historyGrade;
    }

    public String getScienceGrade() {
        return mScienceGrade;
    }

    public void setScienceGrade(String scienceGrade) {
        mScienceGrade = scienceGrade;
    }

    public String getMathsGrade() {
        return mMathsGrade;
    }

    public void setMathsGrade(String mathsGrade) {
        mMathsGrade = mathsGrade;
    }

    public String getArtGrade() {
        return mArtGrade;
    }

    public void setArtGrade(String artGrade) {
        mArtGrade = artGrade;
    }

    @Override
    public String toString() {
        return "Student Report Card :"
                + "Sindhi: " + mSindhiGrade + ", "
                + "Urdu: " + mUrduGrade + ", "
                + "Music: " + mMusicGrade + ", "
                + "English: " + mEnglishGrade + ", "
                + "History: " + mHistoryGrade + ", "
                + "Science: " + mScienceGrade + ", "
                + "Maths: " + mMathsGrade + ", "
                + "Art: " + mArtGrade;
    }
}